# project/server/tests/__init__.py

from project.server.auth.views import auth_blueprint
app.register_blueprint(auth_blueprint)
