# project/tests/test_user_model.py

import unittest
import json

from project.server import db
from project.server.models import User
from project.tests.base import BaseTestCase


class TestUserModel(BaseTestCase):

    def test_encode_auth_token(self):
        """ Test registration with already registered email"""
        user = User(
            email='joel@gmail.com',
            password='test'
        )
        db.session.add(user)
        db.session.commit()
         
        with self.client:
         response = self.client.post(
            '/auth/register',
            data=json.dumps(dict(
                email='joel@gmail.com',
                password='123456'
            )),
            content_type='application/json'
        )
        data = json.loads(response.data.decode())
        self.assertTrue(data['status'] == 'fail')
        self.assertTrue(
            data['message'] == 'User already exists. Please Log in.')
        self.assertTrue(response.content_type == 'application/json')
        self.assertEqual(response.status_code, 202)
        
if __name__ == '__main__':
    unittest.main()